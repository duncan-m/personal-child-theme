# Duncan Malcolm child theme

A WordPress child theme for [Blocksy](https://wordpress.org/themes/blocksy/), with an editable editorial homepage, writing and interview blocks, and a sticky contact bar.

## Installation

[Download duncan-malcolm-theme-v1.1.3.zip](https://github.com/duncan-m/personal-child-theme/raw/refs/heads/main/downloads/duncan-malcolm-theme-v1.1.3.zip)

Use this packaged ZIP for WordPress uploads. GitHub's **Code → Download ZIP** adds a repository-based folder name, which WordPress treats as a different theme.

The package preserves the original identity: folder `duncan-malcolm`, theme name `Duncan Malcolm`, parent `blocksy`, and text domain `duncan-malcolm`. Version 1.1.3 replaces the original 1.1.0 theme. During upload, choose **Replace current with uploaded** when WordPress offers it.

1. Install the free Blocksy parent theme.
2. Upload the packaged `duncan-malcolm` theme ZIP via **Appearance → Themes → Add New → Upload Theme**, then activate it. For a Git checkout, place this repository in `wp-content/themes/duncan-malcolm`.
3. Follow [START-HERE.md](START-HERE.md). The optional **Appearance → Duncan Malcolm Setup** action creates starter content and changes site settings when you apply it.

Requires WordPress 6.6+ and PHP 7.4+. Review [VALIDATION.md](VALIDATION.md) for testing scope and staging checks.

## Version 1.1.3

Theme typography is 10% smaller across desktop and mobile, including the header, hero, editorial blocks, body copy and contact bar. Fixed sizes and responsive clamps share `--dm-type-scale: .9` in `assets/site.css`; layout dimensions and spacing are unchanged. The editor imports the same scaled stylesheet. No setup reapplication is required for this update.

## Version 1.1.2

Featured essay artwork now sits to the right of the copy, including uploaded featured images. On phones up to 480px wide it stacks beneath the copy. The Blocksy header matches the reference with an uppercase serif title, right-aligned navigation, navy contact button and inset divider.

For an existing site, the CSS applies on update. If your header has a different builder layout, use **Appearance → Duncan Malcolm Setup → Reapply layout and links** with your contact URL to restore the reference arrangement. Reapplying also resets starter menu/header customisations. The contact button needs a contact URL. Mobile keeps Blocksy’s menu trigger.

## Version 1.1.1

Merged the supplied CSS into `assets/site.css`:

- Company strip padding: `20px 5px`.
- Writing section padding: `60px 0`.
- Section heading bottom margin: `30px`.
- Interviews top padding: `55px`.

Existing mobile overrides are preserved. The editor imports the same stylesheet. Front-end assets already use modification times for cache invalidation.

## Package from a checkout

From the repository root:

```sh
git archive --format=zip --prefix=duncan-malcolm/ --output=duncan-malcolm-theme-v1.1.3.zip HEAD -- assets blocks patterns templates functions.php inc-editorial.php inc-setup.php style.css theme.json LICENSE.txt README.md START-HERE.md VALIDATION.md validation-results.json
```

Theme source files live at the repository root. No build step or companion plugin is required.
